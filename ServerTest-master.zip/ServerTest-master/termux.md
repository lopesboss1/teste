## Install 'nmap'
```
termux-setup-storage
apt update
apt upgrade 
pkg install nmap
nmap --help
```
